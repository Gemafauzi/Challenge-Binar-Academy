import React from 'react'
import style from './burger.module.css'

const Patty = () => {
  return (
    <div className={style.patty}></div>
  )
}

export default Patty
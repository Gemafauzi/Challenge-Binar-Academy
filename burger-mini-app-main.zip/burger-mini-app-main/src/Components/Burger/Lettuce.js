import React from 'react'
import style from './burger.module.css'

const Lettuce = () => {
  return (
    <div className={style.lettuce}></div>
  )
}

export default Lettuce
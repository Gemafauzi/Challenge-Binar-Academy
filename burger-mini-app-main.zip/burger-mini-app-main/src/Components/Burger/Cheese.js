import React from 'react'
import style from './burger.module.css'

const Cheese = () => {
  return (
    <div className={style.cheese}></div>
  )
}

export default Cheese
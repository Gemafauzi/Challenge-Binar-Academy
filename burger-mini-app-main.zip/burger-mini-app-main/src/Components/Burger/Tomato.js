import React from 'react'
import style from './burger.module.css'

const Tomato = () => {
  return (
    <div className={style.tomato}></div>
  )
}

export default Tomato